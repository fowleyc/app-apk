package com.example.sbprobe;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Stage 1 probe: list paired Bluetooth devices, connect to the one you tap
 * over classic Bluetooth serial (RFCOMM), and show whatever bytes arrive.
 * SMA inverters normally send a first packet right after connecting.
 */
public class MainActivity extends Activity {

    private static final UUID SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private static final int REQ_BT = 1;

    private TextView logView;
    private ScrollView logScroll;
    private ListView listView;
    private final List<BluetoothDevice> devices = new ArrayList<>();
    private volatile boolean busy = false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 24, 24, 24);

        TextView title = new TextView(this);
        title.setText("Tap your inverter (paired devices):");
        title.setTextSize(16);
        root.addView(title);

        listView = new ListView(this);
        root.addView(listView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        logScroll = new ScrollView(this);
        logView = new TextView(this);
        logView.setTextSize(12);
        logView.setTypeface(android.graphics.Typeface.MONOSPACE);
        logView.setTextIsSelectable(true);
        logScroll.addView(logView);
        root.addView(logScroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 2f));

        setContentView(root);

        if (Build.VERSION.SDK_INT >= 31
                && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, REQ_BT);
        } else {
            loadDevices();
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        if (code == REQ_BT && results.length > 0
                && results[0] == PackageManager.PERMISSION_GRANTED) {
            loadDevices();
        } else {
            log("Bluetooth permission was denied. Allow it in the app settings.");
        }
    }

    private BluetoothAdapter adapter() {
        BluetoothManager m = (BluetoothManager) getSystemService(BLUETOOTH_SERVICE);
        return m == null ? null : m.getAdapter();
    }

    private void loadDevices() {
        BluetoothAdapter ad = adapter();
        if (ad == null) {
            log("No Bluetooth on this device.");
            return;
        }
        if (!ad.isEnabled()) {
            log("Bluetooth is off. Turn it on and reopen the app.");
            return;
        }
        List<String> names = new ArrayList<>();
        try {
            Set<BluetoothDevice> bonded = ad.getBondedDevices();
            for (BluetoothDevice d : bonded) {
                devices.add(d);
                names.add(d.getName() + "\n" + d.getAddress());
            }
        } catch (SecurityException e) {
            log("Permission problem: " + e.getMessage());
            return;
        }
        if (names.isEmpty()) log("No paired devices. Pair the inverter in system Bluetooth settings first.");
        listView.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, names));
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> p, View v, int pos, long id) {
                probe(devices.get(pos));
            }
        });
    }

    private void probe(final BluetoothDevice dev) {
        if (busy) {
            log("Already running, wait for it to finish.");
            return;
        }
        busy = true;
        new Thread(new Runnable() {
            @Override
            public void run() {
                BluetoothSocket sock = null;
                try {
                    BluetoothAdapter ad = adapter();
                    if (ad != null) ad.cancelDiscovery();
                    log("Connecting to " + dev.getName() + " ...");
                    try {
                        sock = dev.createRfcommSocketToServiceRecord(SPP);
                        sock.connect();
                    } catch (Exception first) {
                        log("Standard connect failed (" + first.getMessage() + "), trying channel 1 ...");
                        try { if (sock != null) sock.close(); } catch (Exception ignored) { }
                        sock = (BluetoothSocket) dev.getClass()
                                .getMethod("createRfcommSocket", int.class)
                                .invoke(dev, 1);
                        sock.connect();
                    }
                    log("Connected. Listening for 10 seconds ...");
                    InputStream in = sock.getInputStream();
                    long end = System.currentTimeMillis() + 10000;
                    byte[] buf = new byte[1024];
                    int packets = 0;
                    while (System.currentTimeMillis() < end) {
                        if (in.available() > 0) {
                            int n = in.read(buf);
                            if (n > 0) {
                                packets++;
                                log("RX " + n + " bytes: " + hex(buf, n));
                            }
                        } else {
                            Thread.sleep(50);
                        }
                    }
                    log(packets == 0
                            ? "Connected but nothing received. That is still useful to know."
                            : "Done, " + packets + " chunk(s) received. Copy the log and send it to me.");
                } catch (SecurityException e) {
                    log("Permission problem: " + e.getMessage());
                } catch (Exception e) {
                    log("Failed: " + e);
                } finally {
                    try { if (sock != null) sock.close(); } catch (Exception ignored) { }
                    busy = false;
                }
            }
        }).start();
    }

    private static String hex(byte[] b, int n) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) sb.append(String.format("%02X ", b[i]));
        return sb.toString().trim();
    }

    private void log(final String s) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                logView.append(s + "\n");
                logScroll.post(new Runnable() {
                    @Override
                    public void run() { logScroll.fullScroll(View.FOCUS_DOWN); }
                });
            }
        });
    }
}
